Just directly click the html file to run the code
